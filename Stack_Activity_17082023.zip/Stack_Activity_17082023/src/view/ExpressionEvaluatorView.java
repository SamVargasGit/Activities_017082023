package view;

public interface ExpressionEvaluatorView {
    void showResult(double result);
    void showMessage(String errorMessage);
}
