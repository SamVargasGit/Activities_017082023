package view;

import java.util.Set;

public interface PowerSetGeneratorView {
    void displayPowerSet(Set<Set<Integer>> powerSet);
}