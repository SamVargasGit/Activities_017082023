package model;

public class Paciente {
    String name;
    int priority;
    int time;

    public Paciente(String name,int priority){
        this.name=name;
        this.priority=priority;
        this.time=time;
    }
    public String getName(){
        return name;
    }
    public int getPriority(){
        return priority;
    }
    public int getTime(){
        return getTime();
    }
}
